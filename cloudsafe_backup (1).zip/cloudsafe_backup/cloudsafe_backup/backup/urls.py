from django.urls import include, path
from . import views
from rest_framework.routers import DefaultRouter  # Import DefaultRouter
from .api import BackupFileViewSet
router = DefaultRouter()
router.register(r'files', BackupFileViewSet)
urlpatterns = [
    path('', views.index, name='index'),
    path('download/<int:file_id>/', views.download_file, name='download_file'),
    path('logout/', views.logout_view, name='logout'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('register/', views.register, name='register'),
    # path('api/', include(router.urls)),
    path('delete/<int:file_id>/', views.delete_file, name='delete_file'),
]