from django.contrib import admin
from .models import BackupFile

@admin.register(BackupFile)
class BackupFileAdmin(admin.ModelAdmin):
    list_display = ('name', 'user', 'file_type', 'uploaded_at')
    list_filter = ('user', 'file_type')