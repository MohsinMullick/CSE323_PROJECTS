from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import BackupFile
from .serializers import BackupFileSerializer
from rest_framework.permissions import IsAuthenticated
from .google_drive import upload_to_drive
import os

class BackupFileViewSet(viewsets.ModelViewSet):
    queryset = BackupFile.objects.all()
    serializer_class = BackupFileSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return BackupFile.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        file = self.request.FILES.get('file')
        file_type = self.request.data.get('file_type', 'file')

        # Save the file temporarily
        temp_path = f"temp/{file.name}"
        os.makedirs(os.path.dirname(temp_path), exist_ok=True)
        with open(temp_path, 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)

        # Determine file type based on extension if 'file' is selected
        if file_type == 'file':
            ext = file.name.lower().split('.')[-1]
            if ext in ['jpg', 'jpeg', 'png', 'gif']:
                file_type = 'photo'
            elif ext in ['mp4', 'mov', 'avi']:
                file_type = 'video'

        # Upload to Google Drive
        drive_file_id = upload_to_drive(self.request, temp_path, file.name, file_type)

        # Save to database
        serializer.save(
            user=self.request.user,
            name=file.name,
            drive_file_id=drive_file_id,
            file_type=file_type
        )

        # Clean up temporary file
        os.remove(temp_path)