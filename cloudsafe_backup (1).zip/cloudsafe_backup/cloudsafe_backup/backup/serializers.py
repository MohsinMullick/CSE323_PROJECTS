from rest_framework import serializers
from .models import BackupFile

class BackupFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = BackupFile
        fields = ['id', 'name', 'drive_file_id', 'file_type', 'uploaded_at']