from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
from django.http import FileResponse, HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout, login
from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User
import re
import os
import requests
import logging

from backup.models import BackupFile

# Set up logging
logger = logging.getLogger(__name__)

# Custom Registration Form to use email as username and add password validation
class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Email", help_text="Enter a valid email address.")

    class Meta:
        model = User
        fields = ("email", "password1", "password2")

    def clean_email(self):
        email = self.cleaned_data.get("email")
        if User.objects.filter(username=email).exists():
            raise forms.ValidationError("This email is already in use.")
        return email

    def clean_password1(self):
        password1 = self.cleaned_data.get("password1")
        if len(password1) < 8:
            raise forms.ValidationError("Password must be at least 8 characters long.")
        if not re.search(r"[A-Z]", password1):
            raise forms.ValidationError("Password must contain at least one uppercase letter.")
        if not re.search(r"[0-9]", password1):
            raise forms.ValidationError("Password must contain at least one number.")
        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password1):
            raise forms.ValidationError("Password must contain at least one special character.")
        return password1

    def save(self, commit=True):
        user = super().save(commit=False)
        user.username = self.cleaned_data["email"]  # Use email as username
        if commit:
            user.save()
        return user

@login_required
def index(request):
    logger.info(f"Request method: {request.method}, User: {request.user}, Authenticated: {request.user.is_authenticated}")
    files = BackupFile.objects.filter(user=request.user).order_by('-uploaded_at')
    
    # Calculate storage data
    total_storage = 10 * 1024 * 1024 * 1024  # 10GB in bytes
    total_used = sum(file.file.size if file.file else 0 for file in files)
    storage_percentage = (total_used / total_storage) * 100 if total_storage > 0 else 0

    # File counts for categories
    photo_count = files.filter(file_type='photo').count()
    video_count = files.filter(file_type='video').count()
    file_count = files.filter(file_type='file').count()
    
    if request.method == 'POST':
        file = request.FILES.get('file')
        file_type = request.POST.get('file_type')
        if not file:
            return HttpResponse("No file uploaded", status=400)
        
        try:
            # Save the file directly to the database
            backup_file = BackupFile(
                user=request.user,
                name=file.name,
                file=file,
                file_type=file_type,
                uploaded_at=timezone.now()
            )
            backup_file.save()
            
            # Recalculate storage data after upload
            files = BackupFile.objects.filter(user=request.user).order_by('-uploaded_at')
            total_used = sum(file.file.size if file.file else 0 for file in files)
            storage_percentage = (total_used / total_storage) * 100 if total_storage > 0 else 0
            
            return JsonResponse({
                'message': 'File uploaded successfully!',
                'total_used': total_used,
                'total_storage': total_storage,
                'storage_percentage': storage_percentage,
                'file': {
                    'id': backup_file.id,
                    'name': backup_file.name,
                    'file_type': backup_file.file_type,
                    'uploaded_at': backup_file.uploaded_at.strftime('%Y-%m-%d %H:%M:%S'),
                    'size': backup_file.file.size if backup_file.file else 0,
                    'url': backup_file.file.url if backup_file.file else ''
                }
            })
        except Exception as e:
            logger.error(f"Upload failed: {str(e)}")
            return HttpResponse(f"Upload failed: {str(e)}", status=500)
    
    return render(request, 'backup/index.html', {
        'files': files,
        'photo_count': photo_count,
        'video_count': video_count,
        'file_count': file_count,
        'total_used': total_used,
        'total_storage': total_storage,
        'storage_percentage': storage_percentage
    })

@login_required
def download_file(request, file_id):
    file = get_object_or_404(BackupFile, id=file_id, user=request.user)
    return FileResponse(file.file.open(), as_attachment=True, filename=file.name)

@login_required
def delete_file(request, file_id):
    file = get_object_or_404(BackupFile, id=file_id, user=request.user)
    # Delete the file from the filesystem
    if file.file:
        if os.path.exists(file.file.path):
            os.remove(file.file.path)
    file.delete()
    return redirect('index')

def logout_view(request):
    logout(request)
    return redirect('login')

class CustomLoginView(LoginView):
    template_name = 'backup/login.html'
    def form_invalid(self, form):
        # Add error message to context when form is invalid
        return self.render_to_response(self.get_context_data(form=form, error="Invalid email or password."))

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
        else:
            # Pass the form with errors to the template
            return render(request, 'backup/register.html', {'form': form, 'error': 'Please correct the errors below.'})
    else:
        form = CustomUserCreationForm()
    return render(request, 'backup/register.html', {'form': form})