import os
import logging
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2.credentials import Credentials

logger = logging.getLogger(__name__)

SCOPES = ['https://www.googleapis.com/auth/drive.file']

def get_drive_service(request):
    logger.info("Starting Google Drive authentication")
    creds_data = request.session.get('google_drive_token')
    
    if creds_data:
        creds = Credentials(
            token=creds_data['token'],
            refresh_token=creds_data['refresh_token'],
            token_uri=creds_data['token_uri'],
            client_id=creds_data['client_id'],
            client_secret=creds_data['client_secret'],
            scopes=creds_data['scopes']
        )
    else:
        creds = None
    
    if not creds or not creds.valid:
        logger.info("Credentials not found or invalid, initiating OAuth flow")
        flow = InstalledAppFlow.from_client_secrets_file(
            'F:/cloudsafe_backup/cloudsafe_backup/credentials.json',
            SCOPES,
            redirect_uri='http://localhost:8000/oauth2callback'
        )
        
        if 'code' not in request.GET:
            auth_url, state = flow.authorization_url(
                access_type='offline',
                prompt='consent'
            )
            request.session['oauth_state'] = state
            logger.info(f"Generated OAuth URL: {auth_url}")
            return auth_url
        
        logger.info(f"Received OAuth code: {request.GET.get('code')}")
        flow.fetch_token(
            code=request.GET.get('code'),
            state=request.GET.get('state')
        )
        creds = flow.credentials
        request.session['google_drive_token'] = {
            'token': creds.token,
            'refresh_token': creds.refresh_token,
            'token_uri': creds.token_uri,
            'client_id': creds.client_id,
            'client_secret': creds.client_secret,
            'scopes': creds.scopes
        }
        logger.info("Successfully obtained new credentials")
    
    logger.info("Google Drive service created successfully")
    return build('drive', 'v3', credentials=creds)

def upload_to_drive(request, file_path, file_name, file_type):
    service = get_drive_service(request)
    
    if isinstance(service, str):
        return service  # This is the OAuth URL
    
    file_metadata = {
        'name': file_name,
        'mimeType': 'application/octet-stream' if file_type == 'file' else f'image/{file_name.split(".")[-1]}' if file_type == 'photo' else f'video/{file_name.split(".")[-1]}'
    }
    media = MediaFileUpload(file_path)
    file = service.files().create(
        body=file_metadata,
        media_body=media,
        fields='id'
    ).execute()
    logger.info(f"File uploaded to Google Drive with ID: {file.get('id')}")
    return file.get('id')

def delete_from_drive(request, file_id):
    service = get_drive_service(request)
    if isinstance(service, str):
        return service  # This is the OAuth URL
    service.files().delete(fileId=file_id).execute()
    logger.info(f"File deleted from Google Drive with ID: {file_id}")