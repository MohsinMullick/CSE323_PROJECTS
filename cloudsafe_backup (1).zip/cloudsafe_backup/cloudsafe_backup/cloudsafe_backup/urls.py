from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('backup.urls')),  # URLs for the backup app
    path('', include('django.contrib.auth.urls')),  # Include auth URLs at the root
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)